import cv2
import numpy as np
import time as t
import RPi.GPIO as GPIO
from picamera2 import Picamera2
import mediapipe as mp
from pyzbar.pyzbar import decode
import paho.mqtt.client as mqtt
import qrcode
import re
import base64
import io
import pyttsx3
import threading

# ================= MQTT SETUP =================
broker = "test.mosquitto.org"
topic = "hackathon/qrdata"
client = mqtt.Client()
client.connect(broker, 1883, 60)

# ================= CART =================
scanned = set()
cart = {}
total = 0

# ================= AUDIO SETUP =================
engine = pyttsx3.init()
voices = engine.getProperty("voices")
engine.setProperty("voice", voices[4].id)   # choose available voice
engine.setProperty("rate", 115)             # speed
engine.setProperty("volume",1.0)           # volume

def speak_async(msg):
    """Run TTS in background thread (non-blocking)"""
    threading.Thread(target=lambda: (engine.say(msg), engine.runAndWait())).start()

# ================= GPIO MOTOR SETUP =================
IN1A, IN2A, ENA = 17, 27, 22   # Motor A (Right motor)
IN3B, IN4B, ENB = 23, 24, 25   # Motor B (Left motor)
SPEED = 30                    # Motor speed %

GPIO.setmode(GPIO.BCM)
for pin in [IN1A, IN2A, ENA, IN3B, IN4B, ENB]:
    GPIO.setup(pin, GPIO.OUT)

pwm_a = GPIO.PWM(ENA, 100)
pwm_b = GPIO.PWM(ENB, 100)
pwm_a.start(0)
pwm_b.start(0)

def forward(speed=SPEED):
    GPIO.output(IN1A, GPIO.HIGH)
    GPIO.output(IN2A, GPIO.LOW)
    GPIO.output(IN3B, GPIO.HIGH)
    GPIO.output(IN4B, GPIO.LOW)
    pwm_a.ChangeDutyCycle(speed)
    pwm_b.ChangeDutyCycle(speed)

def backward(speed=SPEED):
    GPIO.output(IN1A, GPIO.LOW)
    GPIO.output(IN2A, GPIO.HIGH)
    GPIO.output(IN3B, GPIO.LOW)
    GPIO.output(IN4B, GPIO.HIGH)
    pwm_a.ChangeDutyCycle(speed)
    pwm_b.ChangeDutyCycle(speed)

def turn_left(speed=SPEED):
    GPIO.output(IN1A, GPIO.LOW)
    GPIO.output(IN2A, GPIO.HIGH)
    GPIO.output(IN3B, GPIO.HIGH)
    GPIO.output(IN4B, GPIO.LOW)
    pwm_a.ChangeDutyCycle(speed)
    pwm_b.ChangeDutyCycle(speed)

def turn_right(speed=SPEED):
    GPIO.output(IN1A, GPIO.HIGH)
    GPIO.output(IN2A, GPIO.LOW)
    GPIO.output(IN3B, GPIO.LOW)
    GPIO.output(IN4B, GPIO.HIGH)
    pwm_a.ChangeDutyCycle(speed)
    pwm_b.ChangeDutyCycle(speed)

def stop_motors():
    for pin in [IN1A, IN2A, IN3B, IN4B]:
        GPIO.output(pin, GPIO.LOW)
    pwm_a.ChangeDutyCycle(0)
    pwm_b.ChangeDutyCycle(0)

# ================= CAMERA + DETECTORS =================
picam2 = Picamera2()
picam2.configure(picam2.create_preview_configuration(
    main={"format": 'XRGB8888', "size": (640, 480)}
))
picam2.start()
t.sleep(2)

mp_face = mp.solutions.face_detection
face_detection = mp_face.FaceDetection(min_detection_confidence=0.5)

print("Running QR + Face Following + Billing... Press 'q' to quit.")

# ================= MAIN LOOP =================
try:
    while True:
        frame = picam2.capture_array()

        # ----------- QR CODE SCANNING -----------
        qrcodes = decode(frame)
        for qr in qrcodes:
            qr_data = qr.data.decode("utf-8").strip()

            # --- STOP QR triggers bill ---
            if qr_data.lower() == "stop":
                print("\nðŸ›‘ STOP SCANNED â†’ Generating Bill\n")
                speak_async("Stop scanned. Generating bill.")

                # Bill text
                bill = "ðŸ§¾ BILL\n\n"
                for item, price in cart.items():
                    bill += f"{item}: Rs {price}\n"
                bill += f"\nTOTAL: Rs {total}"

                print(bill)

                # Generate QR of bill
                qr_img = qrcode.make(bill)

                # Convert QR to bytes for MQTT
                buf = io.BytesIO()
                qr_img.save(buf, format="PNG")
                qr_bytes = buf.getvalue()
                qr_b64 = base64.b64encode(qr_bytes).decode("utf-8")

                # Publish bill QR as base64
                client.publish(topic, f"BILL_TEXT:{bill}")
                client.publish(topic, f"BILL_QR:{qr_b64}")
                qr=qrcode.make(total)
                qr.save("bill.png")
                try:
                    qr_np = cv2.imdecode(np.frombuffer(qr_bytes, np.uint8), cv2.IMREAD_COLOR)
                    if qr_np is not None:
                        cv2.imshow("Final Bill (QR)", qr_np)
                        print("Bill QR displayed. Press any key to close.")
                        cv2.waitKey(0)
                except Exception:
                    pass
                print("âœ… Bill sent to mobile over MQTT")

                stop_motors()
                picam2.stop()
                pwm_a.stop()
                pwm_b.stop()
                GPIO.cleanup()
                cv2.destroyAllWindows()
                exit(0)

            # --- PRODUCT QR: Toggle Add / Remove ---
            else:
                # Extract product name + price
                index1 = qr_data.find(" |")
                product = qr_data[9:index1].strip() if index1 != -1 else qr_data
                index_p = qr_data.find("Rs")
                price_digits = re.findall(r'\d+', qr_data[index_p:]) if index_p != -1 else []
                price = int(price_digits[0]) if price_digits else 0

                if qr_data not in scanned:
                    # First scan â†’ Add product
                    scanned.add(qr_data)
                    cart[product] = price
                    total += price
                    print(f"{product} is added!")
                    print(f"Total price: {total}")
                    client.publish(topic, f"Added:{product}, Price:{price}, Total:{total}")
                    speak_async(f"Product {product} added. Price {price} rupees.")
                    t.sleep(2.5)
                else:
                    # Second scan â†’ Remove product
                    scanned.remove(qr_data)
                    if product in cart:
                        total -= cart[product]
                        del cart[product]
                    print(f"{product} is removed!")
                    print(f"Total price: {total}")
                    client.publish(topic, f"Removed:{product}, Total:{total}")
                    speak_async(f"Product {product} removed.")
                    t.sleep(2.5)

            # Draw QR bounding box
            (x, y, w, h) = qr.rect
            cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)

        # ----------- FACE TRACKING -----------
        rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = face_detection.process(rgb_frame)

        h, w, _ = frame.shape
        cx = w // 2
        cy = h // 2

        BOUNDARY_X = 100
        BOUNDARY_Y = 80

        left_boundary = cx - BOUNDARY_X
        right_boundary = cx + BOUNDARY_X
        top_boundary = cy - BOUNDARY_Y
        bottom_boundary = cy + BOUNDARY_Y

        cv2.rectangle(frame, (left_boundary, top_boundary), (right_boundary, bottom_boundary), (0, 255, 255), 2)

        if results.detections:
            for detection in results.detections:
                bboxC = detection.location_data.relative_bounding_box
                x = int(bboxC.xmin * w)
                y = int(bboxC.ymin * h)
                bw = int(bboxC.width * w)
                bh = int(bboxC.height * h)

                face_cx = x + bw // 2
                face_cy = y + bh // 2

                cv2.rectangle(frame, (x, y), (x + bw, y + bh), (0, 255, 0), 2)
                cv2.circle(frame, (face_cx, face_cy), 5, (0, 0, 255), -1)

                if face_cx < left_boundary:
                    turn_right()
                elif face_cx > right_boundary:
                    turn_left()
                elif face_cy < top_boundary:
                    forward()
                elif face_cy > bottom_boundary:
                    backward()
                else:
                    stop_motors()
        else:
            stop_motors()

        # ----------- SHOW CAMERA -----------
        cv2.imshow("QR + Face Tracking + Billing", frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

finally:
    stop_motors()
    pwm_a.stop()
    pwm_b.stop()
    GPIO.cleanup()
    picam2.stop()
    cv2.destroyAllWindows()
    print("Clean exit.")


